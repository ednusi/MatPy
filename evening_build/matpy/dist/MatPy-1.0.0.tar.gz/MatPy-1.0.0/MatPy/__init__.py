"""We are automatically bringing the class into scope"""
from model import stress_strain
